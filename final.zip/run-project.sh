#!/bin/bash
mvn spring-boot:run
