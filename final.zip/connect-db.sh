#!/bin/bash

pgcli -d springboot-api
