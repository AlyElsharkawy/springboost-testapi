package com.example.springboot.dto.bol;

import lombok.Data;

@Data
public class BillOfLadingDTOResponse {
    private String nbr;
    private String companyName;
}
