package com.example.springboot.dto.company;

import lombok.Data;

@Data
public class CompanyDTOResponse {
    private String name;
    private String taxNumber;
}
